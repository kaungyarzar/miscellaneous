#!/usr/bin/env bash

workingDir=$(pwd)

echo "Install sshpass ..."

tar -xvzf sshpass-1.08.tar.gz && cd sshpass-1.08/ && ./configure && echo 'frontiir' | sudo -S make install

echo "Copy shell files and patch to /home/frontiir/fcpe_client/"

cd $workingDir && cp FC*.sh uboot_fix_fcao_fcgo.tar ~/fcpe_client/

echo "Done."
